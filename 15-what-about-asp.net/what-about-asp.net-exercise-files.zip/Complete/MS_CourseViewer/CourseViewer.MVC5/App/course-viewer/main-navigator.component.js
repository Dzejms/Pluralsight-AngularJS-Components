(function () {
    'use strict';

    angular.module('courseViewer').component('mainNavigator', {
        templateUrl: 'App/course-viewer/main-navigator.component.html'
    });
})();
