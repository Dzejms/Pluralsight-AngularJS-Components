(function () {
    'use strict';

    angular.module('courseViewer').component('courseViewerApp', {
        templateUrl: 'App/course-viewer/course-viewer-app.component.html'
    });
})();
