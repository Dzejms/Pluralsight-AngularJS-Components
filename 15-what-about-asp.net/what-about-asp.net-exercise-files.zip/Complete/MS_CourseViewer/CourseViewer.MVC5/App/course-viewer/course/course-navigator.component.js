(function () {
    'use strict';

    angular.module('courseViewer').component('courseNavigator', {
        controllerAs: 'vm',
        controller: function () {
            var vm = this;

        },
        templateUrl: 'App/course-viewer/course/course-navigator.component.html'
    });
})();
