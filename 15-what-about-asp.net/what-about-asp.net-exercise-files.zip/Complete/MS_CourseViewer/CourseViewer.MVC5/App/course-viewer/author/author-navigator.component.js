(function () {
    'use strict';

    angular.module('courseViewer').component('authorNavigator', {
        controllerAs: 'vm',
        controller: function () {
            var vm = this;

        },
        templateUrl: 'App/course-viewer/author/author-navigator.component.html'
    });
})();
