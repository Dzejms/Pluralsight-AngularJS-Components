(function () {
    'use strict';

    angular.module('courseViewer').component('courseViewerApp', {
        templateUrl: 'course-viewer/course-viewer-app.component.html'
    });
})();
