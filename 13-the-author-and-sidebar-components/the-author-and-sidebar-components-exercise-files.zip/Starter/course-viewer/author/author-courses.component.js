(function () {
    'use strict';

    angular.module('courseViewer').component('authorCourses', {
        controllerAs: 'vm',
        controller: function () {
            var vm = this;

        },
        templateUrl: 'course-viewer/author/author-courses.component.html'
    });
})();
