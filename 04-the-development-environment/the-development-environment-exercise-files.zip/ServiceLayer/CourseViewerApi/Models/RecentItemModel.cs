﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CourseViewerWebApi.Models
{
    public class RecentItemModel
    {
        public string UserName { get; set; }
        public int CourseId { get; set; }
    }
}
