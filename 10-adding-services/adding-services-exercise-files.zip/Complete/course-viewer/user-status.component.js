(function () {
    'use strict';

    angular.module('courseViewer').component('userStatus', {
        controllerAs: 'vm',
        controller: function () {
            var vm = this;

        },
        templateUrl: 'course-viewer/user-status.component.html'
    });
})();
