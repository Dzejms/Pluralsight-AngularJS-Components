(function () {
    'use strict';

    angular.module('courseViewer').component('authorHeading', {
        templateUrl: 'course-viewer/author/author-heading.component.html'
    });
})();
