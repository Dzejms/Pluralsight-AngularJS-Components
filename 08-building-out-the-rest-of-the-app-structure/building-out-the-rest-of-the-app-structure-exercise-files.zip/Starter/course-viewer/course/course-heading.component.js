(function () {
    'use strict';

    angular.module('courseViewer').component('courseHeading', {
        templateUrl: 'course-viewer/course/course-heading.component.html'
    });
})();
