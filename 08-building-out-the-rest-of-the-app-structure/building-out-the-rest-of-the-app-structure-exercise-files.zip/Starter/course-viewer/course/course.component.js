(function () {
    'use strict';

    angular.module('courseViewer').component('course', {
        bindings: {
        },
        controllerAs: 'vm',
        controller: function () {
            var vm = this;

        },
        templateUrl: 'course-viewer/course/course.component.html'
    });
})();
