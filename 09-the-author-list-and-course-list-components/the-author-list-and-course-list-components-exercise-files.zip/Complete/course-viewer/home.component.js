(function () {
    'use strict';

    angular.module('courseViewer').component('home', {
        templateUrl: 'course-viewer/home.component.html'
    });
})();
