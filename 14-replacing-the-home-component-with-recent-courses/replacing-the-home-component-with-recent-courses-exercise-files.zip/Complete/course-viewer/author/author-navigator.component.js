(function () {
    'use strict';

    angular.module('courseViewer').component('authorNavigator', {
        controllerAs: 'vm',
        controller: function () {
            var vm = this;

        },
        templateUrl: 'course-viewer/author/author-navigator.component.html'
    });
})();
