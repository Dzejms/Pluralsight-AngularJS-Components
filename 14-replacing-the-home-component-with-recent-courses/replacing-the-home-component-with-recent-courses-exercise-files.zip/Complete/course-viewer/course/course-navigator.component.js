(function () {
    'use strict';

    angular.module('courseViewer').component('courseNavigator', {
        controllerAs: 'vm',
        controller: function () {
            var vm = this;

        },
        templateUrl: 'course-viewer/course/course-navigator.component.html'
    });
})();
